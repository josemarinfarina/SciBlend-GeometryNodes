import bpy
import os
import json
from bpy.types import Operator
from bpy.props import StringProperty

from ..utils import json_parser, node_builder

class SCIBLEND_OT_apply_geometry_nodes(Operator):
    bl_idname = "sciblend.apply_geometry_nodes"
    bl_label = "Aplicar Geometry Nodes"
    bl_description = "Aplica el mapa nodal de Geometry Nodes al objeto seleccionado"
    
    def execute(self, context):
        if not context.active_object:
            self.report({'ERROR'}, "No hay objeto seleccionado")
            return {'CANCELLED'}
        
        json_filepath = context.scene.sciblend_geonodes.json_filepath
        if not json_filepath:
            self.report({'ERROR'}, "No se ha seleccionado un archivo JSON")
            return {'CANCELLED'}
        
        try:
            # Leer el archivo JSON
            with open(bpy.path.abspath(json_filepath), 'r') as f:
                node_data = json.load(f)
            
            # Aplicar el mapa nodal
            self.apply_node_tree(context.active_object, node_data)
            
            self.report({'INFO'}, "Geometry Nodes aplicado correctamente")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error al aplicar Geometry Nodes: {str(e)}")
            return {'CANCELLED'}
    
    def apply_node_tree(self, obj, node_data):
        # Añadir modificador de Geometry Nodes si no existe
        gn_mod = None
        for mod in obj.modifiers:
            if mod.type == 'NODES':
                gn_mod = mod
                break
        
        if not gn_mod:
            gn_mod = obj.modifiers.new(name="GeometryNodes", type='NODES')
        
        # Crear un nuevo árbol de nodos si no existe
        if not gn_mod.node_group:
            node_tree = bpy.data.node_groups.new(name="GeometryNodes", type='GeometryNodeTree')
            gn_mod.node_group = node_tree
        else:
            node_tree = gn_mod.node_group
            # Limpiar nodos existentes
            for node in node_tree.nodes:
                node_tree.nodes.remove(node)
        
        # Crear nodos según la definición JSON
        # Aquí iría la lógica para crear los nodos según el JSON
        # Por simplicidad, este ejemplo no implementa la creación completa
        
        # Crear nodos de entrada y salida
        input_node = node_tree.nodes.new('NodeGroupInput')
        input_node.location = (-200, 0)
        
        output_node = node_tree.nodes.new('NodeGroupOutput')
        output_node.location = (200, 0)
        
        # Conectar entrada y salida
        node_tree.links.new(input_node.outputs[0], output_node.inputs[0])

class SCIBLEND_OT_apply_transformation(Operator):
    bl_idname = "sciblend.apply_transformation"
    bl_label = "Aplicar Transformación"
    bl_description = "Aplica una transformación específica usando Geometry Nodes"
    
    transform_type: StringProperty(
        name="Tipo de Transformación",
        description="Tipo de transformación a aplicar",
        default="translate"
    )
    
    def execute(self, context):
        if not context.active_object:
            self.report({'ERROR'}, "No hay objeto seleccionado")
            return {'CANCELLED'}
        
        # Obtener la ruta del addon
        addon_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        
        # Construir la ruta al archivo JSON correspondiente
        json_filepath = os.path.join(addon_path, "json_templates", f"{self.transform_type}.json")
        
        if not os.path.exists(json_filepath):
            self.report({'ERROR'}, f"No se encontró el archivo JSON para {self.transform_type}")
            return {'CANCELLED'}
        
        try:
            # Leer el archivo JSON
            with open(json_filepath, 'r') as f:
                node_data = json.load(f)
            
            # Aplicar el mapa nodal
            self.apply_node_tree(context.active_object, node_data)
            
            self.report({'INFO'}, f"Transformación {self.transform_type} aplicada correctamente")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error al aplicar transformación: {str(e)}")
            return {'CANCELLED'}
    
    def apply_node_tree(self, obj, node_data):
        # Añadir modificador de Geometry Nodes si no existe
        gn_mod = None
        for mod in obj.modifiers:
            if mod.type == 'NODES':
                gn_mod = mod
                break
        
        if not gn_mod:
            gn_mod = obj.modifiers.new(name="GeometryNodes", type='NODES')
        
        # Crear un nuevo árbol de nodos si no existe
        if not gn_mod.node_group:
            node_tree = bpy.data.node_groups.new(name=f"GN_{self.transform_type}", type='GeometryNodeTree')
            gn_mod.node_group = node_tree
        else:
            node_tree = gn_mod.node_group
            node_tree.name = f"GN_{self.transform_type}"
            # Limpiar nodos existentes
            for node in node_tree.nodes:
                node_tree.nodes.remove(node)
        
        # Crear nodos según la definición JSON
        input_node = node_tree.nodes.new('NodeGroupInput')
        input_node.location = (-200, 0)
        
        output_node = node_tree.nodes.new('NodeGroupOutput')
        output_node.location = (400, 0)
        
        # Crear nodo de transformación según el tipo
        if self.transform_type == "translate":
            transform_node = node_tree.nodes.new('GeometryNodeTransform')
            transform_node.location = (100, 0)
            transform_node.inputs[1].default_value = (1, 0, 0)  # Traslación en X
            
            # Conectar nodos
            node_tree.links.new(input_node.outputs[0], transform_node.inputs[0])
            node_tree.links.new(transform_node.outputs[0], output_node.inputs[0])
            
        elif self.transform_type == "rotate":
            transform_node = node_tree.nodes.new('GeometryNodeTransform')
            transform_node.location = (100, 0)
            transform_node.inputs[2].default_value = (0, 0, 0.785398)  # Rotación 45 grados en Z
            
            # Conectar nodos
            node_tree.links.new(input_node.outputs[0], transform_node.inputs[0])
            node_tree.links.new(transform_node.outputs[0], output_node.inputs[0])
            
        elif self.transform_type == "scale":
            transform_node = node_tree.nodes.new('GeometryNodeTransform')
            transform_node.location = (100, 0)
            transform_node.inputs[3].default_value = (2, 2, 2)  # Escala x2
            
            # Conectar nodos
            node_tree.links.new(input_node.outputs[0], transform_node.inputs[0])
            node_tree.links.new(transform_node.outputs[0], output_node.inputs[0])
            
        elif self.transform_type == "mirror":
            transform_node = node_tree.nodes.new('GeometryNodeMirror')
            transform_node.location = (100, 0)
            transform_node.inputs[1].default_value = True  # Espejo en X
            
            # Conectar nodos
            node_tree.links.new(input_node.outputs[0], transform_node.inputs[0])
            node_tree.links.new(transform_node.outputs[0], output_node.inputs[0])
            
        elif self.transform_type == "array":
            transform_node = node_tree.nodes.new('GeometryNodeInstanceOnPoints')
            transform_node.location = (100, 0)
            
            # Crear nodo para generar puntos en una línea
            line_node = node_tree.nodes.new('GeometryNodeMeshLine')
            line_node.location = (-50, -100)
            line_node.inputs[0].default_value = 5  # 5 puntos
            line_node.inputs[1].default_value = 2.0  # Longitud 2
            
            # Conectar nodos
            node_tree.links.new(input_node.outputs[0], transform_node.inputs[2])  # Instancia
            node_tree.links.new(line_node.outputs[0], transform_node.inputs[0])  # Puntos
            node_tree.links.new(transform_node.outputs[0], output_node.inputs[0])

classes = (
    SCIBLEND_OT_apply_geometry_nodes,
    SCIBLEND_OT_apply_transformation,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls) 