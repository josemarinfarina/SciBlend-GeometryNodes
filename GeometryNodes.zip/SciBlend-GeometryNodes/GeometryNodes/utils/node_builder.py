import bpy

def build_and_apply_node_tree(obj, data):
    """
    Construye y aplica un árbol de nodos de Geometry Nodes a un objeto a partir de datos JSON.
    
    Args:
        obj (bpy.types.Object): Objeto al que aplicar el árbol de nodos
        data (dict): Datos JSON que definen el árbol de nodos
        
    Returns:
        bool: True si se aplicó correctamente, False en caso contrario
    """
    # Crear un nuevo modificador de Geometry Nodes si no existe
    if not any(mod.type == 'NODES' for mod in obj.modifiers):
        modifier = obj.modifiers.new(name="GeometryNodes", type='NODES')
    else:
        # Usar el primer modificador de Geometry Nodes existente
        modifier = next(mod for mod in obj.modifiers if mod.type == 'NODES')
    
    # Crear un nuevo árbol de nodos si no existe
    if modifier.node_group is None:
        node_group = bpy.data.node_groups.new(name=f"{obj.name}_GeometryNodes", type='GEOMETRY')
        modifier.node_group = node_group
    else:
        node_group = modifier.node_group
        # Limpiar el árbol de nodos existente
        for node in node_group.nodes:
            node_group.nodes.remove(node)
    
    # Asegurarse de que el árbol de nodos tiene los nodos de entrada y salida
    setup_node_tree_io(node_group)
    
    # Crear los nodos según el JSON
    node_map = create_nodes(node_group, data['nodes'])
    
    # Crear los enlaces según el JSON
    create_links(node_group, data['links'], node_map)
    
    return True

def setup_node_tree_io(node_group):
    """
    Configura los nodos de entrada y salida en un árbol de nodos de Geometry Nodes.
    
    Args:
        node_group (bpy.types.NodeTree): Árbol de nodos a configurar
    """
    # Crear nodo de entrada si no existe
    input_node = None
    output_node = None
    
    for node in node_group.nodes:
        if node.type == 'GROUP_INPUT':
            input_node = node
        elif node.type == 'GROUP_OUTPUT':
            output_node = node
    
    if input_node is None:
        input_node = node_group.nodes.new(type='NodeGroupInput')
        input_node.location = (-600, 0)
    
    if output_node is None:
        output_node = node_group.nodes.new(type='NodeGroupOutput')
        output_node.location = (600, 0)
    
    # Asegurarse de que hay una entrada de geometría
    if 'Geometry' not in [input.name for input in node_group.inputs]:
        node_group.inputs.new('NodeSocketGeometry', "Geometry")
    
    # Asegurarse de que hay una salida de geometría
    if 'Geometry' not in [output.name for output in node_group.outputs]:
        node_group.outputs.new('NodeSocketGeometry', "Geometry")

def create_nodes(node_group, nodes_data):
    """
    Crea los nodos en un árbol de nodos de Geometry Nodes según los datos JSON.
    
    Args:
        node_group (bpy.types.NodeTree): Árbol de nodos donde crear los nodos
        nodes_data (list): Lista de diccionarios con datos de nodos
        
    Returns:
        dict: Mapeo de IDs de nodos en el JSON a nodos creados en Blender
    """
    node_map = {}
    
    for node_data in nodes_data:
        # Obtener el tipo de nodo
        node_type = node_data['type']
        
        # Crear el nodo
        node = node_group.nodes.new(type=node_type)
        node.name = node_data['name']
        
        # Establecer la posición del nodo
        if 'location' in node_data:
            node.location = (node_data['location'][0], node_data['location'][1])
        
        # Configurar propiedades del nodo
        if 'properties' in node_data:
            for prop_name, prop_value in node_data['properties'].items():
                if hasattr(node, prop_name):
                    setattr(node, prop_name, prop_value)
        
        # Configurar entradas del nodo
        if 'inputs' in node_data:
            for i, input_value in enumerate(node_data['inputs']):
                if i < len(node.inputs) and hasattr(node.inputs[i], 'default_value'):
                    node.inputs[i].default_value = input_value
        
        # Guardar el nodo en el mapeo
        node_map[node_data.get('id', node_data['name'])] = node
    
    return node_map

def create_links(node_group, links_data, node_map):
    """
    Crea los enlaces entre nodos en un árbol de nodos de Geometry Nodes según los datos JSON.
    
    Args:
        node_group (bpy.types.NodeTree): Árbol de nodos donde crear los enlaces
        links_data (list): Lista de diccionarios con datos de enlaces
        node_map (dict): Mapeo de IDs de nodos en el JSON a nodos creados en Blender
    """
    for link_data in links_data:
        # Obtener los nodos de origen y destino
        from_node_id = link_data['from_node']
        to_node_id = link_data['to_node']
        
        if from_node_id not in node_map or to_node_id not in node_map:
            continue
        
        from_node = node_map[from_node_id]
        to_node = node_map[to_node_id]
        
        # Obtener los sockets de origen y destino
        from_socket_name = link_data['from_socket']
        to_socket_name = link_data['to_socket']
        
        # Encontrar los sockets por nombre o índice
        from_socket = None
        to_socket = None
        
        # Intentar encontrar por nombre
        for socket in from_node.outputs:
            if socket.name == from_socket_name:
                from_socket = socket
                break
        
        for socket in to_node.inputs:
            if socket.name == to_socket_name:
                to_socket = socket
                break
        
        # Si no se encontró por nombre, intentar por índice
        if from_socket is None and from_socket_name.isdigit():
            idx = int(from_socket_name)
            if idx < len(from_node.outputs):
                from_socket = from_node.outputs[idx]
        
        if to_socket is None and to_socket_name.isdigit():
            idx = int(to_socket_name)
            if idx < len(to_node.inputs):
                to_socket = to_node.inputs[idx]
        
        # Crear el enlace si se encontraron los sockets
        if from_socket is not None and to_socket is not None:
            node_group.links.new(from_socket, to_socket) 