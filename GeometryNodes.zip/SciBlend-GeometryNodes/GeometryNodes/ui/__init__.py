from . import panels

def register():
    panels.register()

def unregister():
    panels.unregister() 