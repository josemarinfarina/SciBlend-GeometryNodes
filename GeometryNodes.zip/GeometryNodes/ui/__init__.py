from . import new_panels as panels

def register():
    panels.register()

def unregister():
    panels.unregister() 